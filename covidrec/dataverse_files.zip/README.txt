World COVID-19 daily cases with basemap, starting from January 22, 2020.

*COVID-19 Data Source: https://github.com/CSSEGISandData/COVID-19
*Basemap: https://hub.arcgis.com/datasets/a21fdb46d23e4ef896f31475217cbb08_1